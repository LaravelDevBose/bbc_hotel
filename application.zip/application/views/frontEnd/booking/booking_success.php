<div class="container">
	<div class="row">
		
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-success">
			  	<div class="panel-heading">
			    	<h3 class="panel-title">Booking Succes Message</h3>
			  	</div>
			  	<div class="panel-body">
			  		<div class="alert">
			  			<p class="alert-success" style="padding: 15px;"><strong>Thank You.</strong> Your Booking is successfully Complate. We will Contact With You Soon. </p>
			  		</div>
					<p class="text-info">For Emergency: <b><?php if($phone && isset($phone)){echo $phone->value; }?></b> </p>
			  	</div>
			</div>
		</div>
	</div>
</div>