<div class="vd_navbar vd_nav-width vd_navbar-tabs-menu vd_navbar-left  ">
    
    <div class="navbar-menu clearfix">
        <br>
        <div class="vd_menu">
            <ul>
                <li>
                    <a href="<?= base_url();?>dashboard">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Dashboard</span>  
                    </a> 
                </li>
                <li>
                    <a href="<?= base_url(); ?>booking_list">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Booking List</span>  
                    </a> 
                </li>
                
                <li>
                    <a href="<?= base_url();?>gallery_page">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Photo Gallary</span>  
                    </a> 
                </li>

                <li>
                    <a href="<?= base_url();?>sliders">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Slider</span>  
                    </a> 
                </li>
                <li>
                    <a href="<?= base_url();?>logo_page">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Logo</span>  
                    </a> 
                </li>
                <li>
                    <a href="<?= base_url(); ?>area_page">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Area List</span>  
                    </a> 
                </li>
                <li>
                    <a href="<?= base_url(); ?>room_type_page">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Room Type List</span>  
                    </a> 
                </li>
                <li>
                    <a href="<?= base_url(); ?>area_room_type">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Area Wise Room List</span>  
                    </a> 
                </li>

                <li>
                    <a href="<?= base_url(); ?>service_page">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Service & Price</span>  
                    </a> 
                </li>
                <li>
                    <a href="<?= base_url();?>package_page">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Package List</span>  
                    </a> 
                </li>

                
                

                <li>
                    <a href="<?= base_url();?>about_insert_page">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">About Us</span>  
                    </a> 
                </li>

                <li>
                    <a href="<?= base_url();?>contact_us_page">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Contact Us</span>  
                    </a> 
                </li>

                <li>
                    <a href="<?= base_url();?>wellcome_note">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Welcome Note</span>  
                    </a> 
                </li>

                <li>
                    <a href="<?= base_url();?>admin_page">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Admin</span>  
                    </a> 
                </li>

                <!-- <li>
                    <a href="javascript:void(0);" data-action="click-trigger">
                        <span class="menu-icon"><i class="fa fa-dashboard"></i></span> 
                        <span class="menu-text">Left Menu</span>  
                        <span class="menu-badge"><span class="badge vd_bg-black-30"><i class="fa fa-angle-down"></i></span></span>
                    </a>
                    <div class="child-menu"  data-action="click-target">
                        <ul>
                            <li>
                                <a href="index.html">
                                    <span class="menu-text">About Dr. Nasir</span>  
                                </a>
                            </li>                                                                                                         
                        </ul>   
                    </div>
                </li>   -->
                       
                  

            </ul>
            <!-- Head menu search form ends -->         
        </div>             
    </div>
    
    <div class="vd_menu vd_navbar-bottom-widget">
        <ul>
            <li>
                <a href="<?= base_url(); ?>admin/logout">
                    <span class="menu-icon"><i class="fa fa-sign-out"></i></span>          
                    <span class="menu-text">Logout</span>             
                </a>

            </li>
        </ul>
    </div>     
</div>



